// function setup() {
//   createCanvas(400, 400);
//   background(0);
//   fill(255,255,0);
//   ellipse(200,200,100,100);
//   fill(0,0,0);
//   triangle(200,200,400,100,400,300);
// }

// function draw() {
//   // background(0);
//   // fill(255,255,0);
//   // ellipse(200,200,100,100);
//   // fill(0,0,0);
//   // triangle(200,200,400,100,400,300);
// }

// function mousePressed(){
//   background(0);
//   fill(255,255,0);
//   ellipse(200,200,100,100);
// }

// function mouseReleased(){
//   fill(255,255,0);
//   ellipse(200,200,100,100);
//   fill(0,0,0);
//   triangle(200,200,400,100,400,300);
//}

var pacmanU;
var pacmanD;

var pacmanBodyX;
var pacmanBodyY;

function setup(){
  createCanvas(400, 400);
  pacmanU=PI/4;
  pacmanD=1.8*PI;
  pacmanBodyX=0;
  pacmanBodyY=0;
}

function draw(){
  background(0,0,0);
  noStroke();
  fill(255,255,0);
  arc(pacmanBodyX,pacmanBodyY,100,100,pacmanU,pacmanD);
  if(keyIsPressed==true){
    ellipse(pacmanBodyX,pacmanBodyY,100,100);
    if(key=='w'){
   pacmanU=1.5*PI+PI/4;
   pacmanD=1.5*PI-PI/4;
   pacmanBodyY=pacmanBodyY-1;
   }
 if(key=='a'){
   pacmanU=PI+PI/4;
   pacmanD=PI-PI/4;
   pacmanBodyX=pacmanBodyX-1;
   }
    if(key=='s'){
   pacmanU=PI/2+PI/4;
   pacmanD=PI/2-PI/4;
   pacmanBodyY=pacmanBodyY+1;
   }
    if(key=='d'){
   pacmanU=PI/4;
   pacmanD=PI*1.8
   pacmanBodyX=pacmanBodyX+1;
   }
  }
  if(mouseIsPressed){
    // ellipse(pacmanBodyX,pacmanBodyY,100,100);
  }
}